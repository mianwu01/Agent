# 08 来源与演变

## Marwa 8/21 原话要点（`0cda4bd14e`，只列原话部分第 11–27 条）

| 条 | 原话要点 |
|---|---|
| 13 | Simon Yu 那篇在 CooperBench 上 "incredibly expensive"，"did not tackle the problem of generating trajectories" |
| 17 | "generate trajectories for a variety of benchmarks … less expensive, shorter time" |
| 18 | 可以看 τ-bench，"version 2 is very long horizon" |
| 19–20 | 搭 benchmark 要大量 prompt engineering；simulator collapse；"How do you ensure that you're generating diverse enough trajectories?" |
| 21 | 拒绝合作有多种发生方式，"just by prompting once, you haven't found all modes" |
| 22–23 | 想从数学上说明探索了足够的 state-action 空间；又说 intractable，"you don't know what you don't know" |
| 25 | 通常靠领域知识生成行为；"exploration that's useful for the reward is very difficult" |

第 31–39 条是你会后写的分析（三段论证链、收窄到 failure-mode coverage、主指标 cost per novel validated failure mode），不是 Marwa 的话。8/23 片段（`31ab1598de`，说话人不明）：让 agent 反思失败并更新 prompt，很短视、一次只修一个、过拟合。

## 定义的演变

| 版本 | 核心 | 为什么改 |
|---|---|---|
| 8/21 分析 | 固定 rollout 预算下发现更多经验证失败模式；cost per novel validated failure mode | 收窄 Marwa 的"轨迹生成"，因为 state-action 覆盖做不到 |
| v1–v2（10/2–10/3） | 模式卡、(s,d,Δ) 对照、telecom 开发环境；三臂 / 五臂对照 | 实体定义和证据标准逐步清楚 |
| v3 | 两层定位：方法层是伙伴行为生成，评估层是经验证失败 | 发现"找失败"是对 Marwa 的收窄 |
| v4 | 统计保证为核心（无偏频率、剩余风险、Good-UCB 分配） | 担心方法太简单；读了 Go-Explore、MADRID、AST、STADS 等 |
| v5 | 回到 Marwa 原意：伙伴行为覆盖度 + 训练用途；环境梯子 P4G → τ² → CooperBench | 只看她的原话重读 |
| **v6** | **insight（局部性 + 不典型性）+ Pivot-and-Probe + 评测 / 训练双用途** | v5 离 2608.12253 太近（同环境、同训练比较、做它的 future work）；v4 过于强调数学；读 ProVer 和 VS 原文后确定新意的位置 |

## 讨论中撤回或降级的结论（v4 之后新增的）

1. "以统计保证为核心"：撤回。命题 1、2 是分裂法的已知性质，校准实验不会以有意思的方式失败，回答不了项目行不行。降为附录分析工具。
2. "按缺失质量分配预算是可能的新贡献"：撤回。Entropic（Böhme 等 FSE 2020，凭记忆，待核对）已按信息增益分配；节点固定时 (1−1/e) 是 Golovin & Krause 定理的直接推论。
3. Twisted SMC 作为方法核心：撤回，降为可选的分析框架（太强调数学，偏离"方法 + 评测 + 训练"）。
4. v5 的环境梯子：撤回。P4G 和 CooperBench 是 2608.12253 的环境，继承它们会让我们读起来像它的续篇；环境按阶段 1 的测量结果选。
5. "定位是方法核心"：撤回。ProVer 已经做了 judge 定位 + 前后续写验证（2609.36178 的 3.3–3.4），只能借用。
6. "提议者看到已找到的行为、生成不同的"作为新意：撤回。这就是 VS-Multi（2510.01171 的 4-S22）。新意只剩结果引导和忠实性约束。
7. "项目就是发现更多行为"：更正。目标是发现更多**要紧的**行为；按不同行为总数计我们预期会输给 VS，论文主动报告。
8. "省钱是卖点"：更正。省钱是手段；质变在于找到 iid 碰不到的失败、训练迁移更好。
9. 单点对照足以检出所有失败：更正。下游关键点会按比例稀释效应，需局部结果、成功轨迹搞坏、孤儿失败剥离三种补救。

v1–v4 期间撤回的 18 条见 `p4_handoff_v4_2026-10-03/02_sources_history.md`。
